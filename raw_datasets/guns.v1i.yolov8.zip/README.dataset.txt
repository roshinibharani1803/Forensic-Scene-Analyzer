# gun_detection > 2025-12-03 1:29pm
https://universe.roboflow.com/manisha-k1r2z/gun_detection-enjv5

Provided by a Roboflow user
License: CC BY 4.0

